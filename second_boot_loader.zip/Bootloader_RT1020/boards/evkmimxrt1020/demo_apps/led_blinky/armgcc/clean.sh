#!/bin/sh
rm -rf debug release sdram_debug sdram_release flexspi_nor_debug flexspi_nor_release CMakeFiles
rm -rf Makefile cmake_install.cmake CMakeCache.txt
